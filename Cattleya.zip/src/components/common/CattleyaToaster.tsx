"use client";

import { Toaster } from "sonner";

export default function CattleyaToaster() {
  return (
    <Toaster
      theme="light"
      position="top-right"
      offset={{
        top: "104px",
        right: "32px",
      }}
      duration={5200}
      visibleToasts={3}
      closeButton={false}
      gap={16}
      toastOptions={{
        classNames: {
          toast:
            "group relative w-[390px] overflow-hidden rounded-none border border-[#d6bc91]/35 bg-[#fbf6ee]/95 px-5 py-4 text-[#17110b] shadow-[0_28px_90px_rgba(23,17,11,0.18)] backdrop-blur-2xl before:pointer-events-none before:absolute before:right-4 before:top-4 before:h-24 before:w-24 before:bg-[radial-gradient(circle,rgba(214,188,145,0.55)_0_2px,transparent_3px)] before:opacity-40 after:pointer-events-none after:absolute after:inset-0 after:bg-[linear-gradient(115deg,transparent_0%,rgba(214,188,145,0.16)_42%,rgba(255,255,255,0.45)_50%,rgba(214,188,145,0.12)_58%,transparent_100%)]",
          title:
            "text-[10px] uppercase tracking-[0.34em] text-[#8a6a3f]",
          description:
            "mt-2 text-[13px] font-light leading-6 tracking-[-0.01em] text-black/58",
          icon: "text-[#8a6a3f]",
        },
      }}
    />
  );
}