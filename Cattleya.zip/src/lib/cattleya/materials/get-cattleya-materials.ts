import { createClient } from "@supabase/supabase-js";

export type CattleyaMaterial = {
  id: string;
  handle: string;
  label: string;
  title: string;
  description: string;
  media_type: "image" | "video";
  media_url: string;
  hero_title: string | null;
  hero_description: string | null;
  hero_media_url: string | null;
};

export async function getCattleyaMaterials(): Promise<CattleyaMaterial[]> {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!supabaseUrl || !supabaseAnonKey) {
    return [];
  }

  const supabase = createClient(supabaseUrl, supabaseAnonKey);

  const { data } = await supabase
    .from("cattleya_materials")
    .select(`
      id,
      handle,
      label,
      title,
      description,
      media_type,
      media_url,
      hero_title,
      hero_description,
      hero_media_url
    `)
    .eq("is_active", true)
    .order("sort_order", { ascending: true });

  return (data ?? []) as CattleyaMaterial[];
}