import Link from "next/link";
import {
  Bag,
  MagnifyingGlass,
  User,
} from "phosphor-react";

type HeaderPCActionsProps = {
  onSearchOpen: () => void;
  onCartOpen: () => void;
  forceColor?: "white" | "black";
};

export default function HeaderPCActions({
  onSearchOpen,
  onCartOpen,
  forceColor = "black",
}: HeaderPCActionsProps) {
  const colorClass =
    forceColor === "white"
      ? "text-white"
      : "text-black";

  return (
    <div className="flex items-center justify-end gap-7">
      <button
        type="button"
        onClick={onSearchOpen}
        className={`group flex items-center gap-3 text-[10px] uppercase tracking-[0.3em] ${colorClass}/70 transition hover:${colorClass}`}
      >
        <MagnifyingGlass
          size={17}
          weight="light"
        />

        Recherche
      </button>

      <Link
        href="/pc/account"
        className={`group flex items-center gap-3 text-[10px] uppercase tracking-[0.3em] ${colorClass}/70 transition hover:${colorClass}`}
      >
        <User size={17} weight="light" />

        Compte
      </Link>

      <button
        type="button"
        onClick={onCartOpen}
        className={`group flex items-center gap-3 text-[10px] uppercase tracking-[0.3em] ${colorClass}/70 transition hover:${colorClass}`}
      >
        <Bag size={17} weight="light" />

        Panier
      </button>
    </div>
  );
}